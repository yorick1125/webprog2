Endpoints:
GET - localhost:1339/home -> homepage
POST - localhost:1339/album/new -> create, sample json {title: "KOD", year: "2018"}
GET - localhost:1339/album/all -> list
GET - localhost:1339/album/show -> find
PUT - localhost:1339/album/update -> update
DELETE - localhost:1339/album/removal -> delete
